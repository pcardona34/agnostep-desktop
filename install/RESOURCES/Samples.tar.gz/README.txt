SAMPLE FOLDER

Most of the files provided in this Sample Folder come from Sample.cat:
https://sample.cat
List: .html, .gif, .jpg, .mkv (like .webm); .mp4 (like .mov); .mp3, .ogg, .png, .svg, .tiff, .webp, .zip.

The epub sample comes from File-Samples.com 
List: *.epub

Other files were created by their own app within PiSi Desktop:
List: .txt, .help, .lsf, .rtfd, .chess, .gdr, .vcf

PDF sample comes from GNUstep documentation:
.pdf
